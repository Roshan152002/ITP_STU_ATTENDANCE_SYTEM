from django.shortcuts import get_object_or_404, render
from attendance.models import Course, Student,Subject,Teacher
from django.contrib.auth.decorators import login_required

@login_required(login_url='/')
def teacher_home(request):
    return render(request,'teacher/home.html')


def take_attendance(request):
    teacher = get_object_or_404(Teacher, user=request.user)
    courses =Course.objects.all()
    subjects = Subject.objects.filter(teacher=teacher.user.id)
    
    if request.method == 'POST':
        if 'fetch_data' in request.POST :
            selected_course = request.POST.get('selected_course')
            selected_subject = request.POST.get('selected_subject')
            selected_date = request.POST.get('selected_date')
            
            students = Student.objects.filter(course=selected_course)
            subjects = Subject.objects.filter(id=selected_subject)
            return render(request, "teacher/take_attendance.html",{'selected_course':selected_course,'selected_subject':selected_subject,'selected_date':selected_date,'students':students})
                    
        # elif 'submit_attendance' in request.POST:
        #     selected_date = request.POST.get('selected_date')
        #     selected_subject = request.POST.get('selected_subject')
        #     selected_course = request.POST.get('selected_course')
        #     selected_students = request.POST.getlist('selected_students')
        #     course = Course.objects.get(id=selected_course)
        #     subject = Subject.objects.get(id=selected_subject)
            
        #     for student_id in selected_students:
        #         student = course.student_set.get(id=student_id)
        #         attendance, created = Attendance.objects.get_or_create(student=student, subject=subject, date=selected_date)
        #         attendance.present = True
        #         attendance.save()
    
    return render(request,"teacher/take_attendance.html",{'courses':courses,'subjects':subjects})